export { useSimulationStore } from './simulation'
export type { SimulationState, SimulationSpeed, TrainPosition } from './simulation'
